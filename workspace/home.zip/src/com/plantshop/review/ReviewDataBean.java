package com.plantshop.review;

public class ReviewDataBean {
	private int id;
	private String name;
	private String inputdate;
	private String subject;
	private String content;
	private int pid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInputdate() {
		return inputdate;
	}

	public void setInputdate(String inputdate) {
		this.inputdate = inputdate;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	@Override
	public String toString() {
		return "ReviewDataBean [id=" + id + ", name=" + name + ", inputdate=" + inputdate + ", subject=" + subject
				+ ", content=" + content + ", pid=" + pid + "]";
	}

}
