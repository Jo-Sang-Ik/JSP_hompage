package com.plantshop.item;

public class ItemDataBean {
	private int orderid;
	private int itemno;
	private int productid;
	private String pname;
	private int quantity;
	private int price;

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public int getItemno() {
		return itemno;
	}

	public void setItemno(int itemno) {
		this.itemno = itemno;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "ItemDataBean [orderid=" + orderid + ", itemno=" + itemno + ", productid=" + productid + ", pname="
				+ pname + ", quantity=" + quantity + ", price=" + price + "]";
	}
}
