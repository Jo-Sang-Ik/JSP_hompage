package com.plantshop.freeboard;

public class FreeBoardDataBean {
	private int id;
	private String name;
	private String password;
	private String email;
	private String subject;
	private String content;
	private String inputdate;
	private int masterid;
	private int readcount;
	private int replynum;
	private int step;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getInputdate() {
		return inputdate;
	}

	public void setInputdate(String inputdate) {
		this.inputdate = inputdate;
	}

	public int getMasterid() {
		return masterid;
	}

	public void setMasterid(int masterid) {
		this.masterid = masterid;
	}

	public int getReadcount() {
		return readcount;
	}

	public void setReadcount(int readcount) {
		this.readcount = readcount;
	}

	public int getReplynum() {
		return replynum;
	}

	public void setReplynum(int replynum) {
		this.replynum = replynum;
	}

	public int getStep() {
		return step;
	}

	public void setStep(int step) {
		this.step = step;
	}

	@Override
	public String toString() {
		return "FreeBoardDataBean [id=" + id + ", name=" + name + ", password=" + password + ", email=" + email
				+ ", subject=" + subject + ", content=" + content + ", inputdate=" + inputdate + ", masterid="
				+ masterid + ", readcount=" + readcount + ", replynum=" + replynum + ", step=" + step + "]";
	}

}
