select * from member2;
desc member2;